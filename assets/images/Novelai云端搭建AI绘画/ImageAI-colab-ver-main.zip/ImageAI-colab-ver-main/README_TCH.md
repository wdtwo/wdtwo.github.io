[English](README.md) | 繁體中文
# ImageAI-colab-版
[Google Colab](https://colab.research.google.com/)

這跟 novel 一點關係都沒有。

# 你可能需要 [這支影片](https://www.youtube.com/watch?v=TyIL7XjMUaw) 來教你如何使用 txt 檔
<a href="http://www.youtube.com/watch?feature=player_embedded&v=TyIL7XjMUaw" target="_blank">
 <img src="http://img.youtube.com/vi/TyIL7XjMUaw/mqdefault.jpg" alt="Watch the video"/>
</a>

## [教學影片](https://www.youtube.com/watch?v=7DWMz_fMsAo)
<a href="http://www.youtube.com/watch?feature=player_embedded&v=7DWMz_fMsAo" target="_blank">
 <img src="http://img.youtube.com/vi/7DWMz_fMsAo/mqdefault.jpg" alt="Watch the video"/>
</a>
