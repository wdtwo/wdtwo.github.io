English | [繁體中文](README_TCH.md)
# ImageAI-colab-ver
[Google Colab](https://colab.research.google.com/)

It has no matter with novel.

# You may need [this video](https://www.youtube.com/watch?v=TyIL7XjMUaw) for how to use txt file
<a href="http://www.youtube.com/watch?feature=player_embedded&v=TyIL7XjMUaw" target="_blank">
 <img src="http://img.youtube.com/vi/TyIL7XjMUaw/mqdefault.jpg" alt="Watch the video"/>
</a>

## [Tutorial Video](https://www.youtube.com/watch?v=7DWMz_fMsAo)
<a href="http://www.youtube.com/watch?feature=player_embedded&v=7DWMz_fMsAo" target="_blank">
 <img src="http://img.youtube.com/vi/7DWMz_fMsAo/mqdefault.jpg" alt="Watch the video"/>
</a>
